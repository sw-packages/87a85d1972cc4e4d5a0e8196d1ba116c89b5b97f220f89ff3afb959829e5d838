//
// Orthodox.h
//


#ifndef Poco_CppUnit_Orthodox_INCLUDED
#define Poco_CppUnit__INCLUDED

#include "CppUnit/Orthodox.h"

#endif // Poco_CppUnit_Orthodox_INCLUDED
